import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
 modal:any = document.getElementById('id01');
  constructor() { }

  ngOnInit(): void {
  }
  // Get the modal


// When the user clicks anywhere outside of the modal, close it


}
