import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-learderboard',
  templateUrl: './learderboard.component.html',
  styleUrls: ['./learderboard.component.css']
})
export class LearderboardComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
