import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-livechat',
  templateUrl: './livechat.component.html',
  styleUrls: ['./livechat.component.css']
})
export class LivechatComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
